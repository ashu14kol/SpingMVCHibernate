package com.cybage.scriptmanagement.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Lazy;

public class TestScriptDTO implements Serializable {

	private int testScriptId;
	private String testScriptTitle;
	private String testScriptDescription;
	private String testScriptExecutionInstruction;
	private String testScriptDataset;

	public int getTestScriptId() {
		return testScriptId;
	}

	public void setTestScriptId(int testScriptId) {
		this.testScriptId = testScriptId;
	}

	public String getTestScriptTitle() {
		return testScriptTitle;
	}

	public void setTestScriptTitle(String testScriptTitle) {
		this.testScriptTitle = testScriptTitle;
	}

	public String getTestScriptDescription() {
		return testScriptDescription;
	}

	public void setTestScriptDescription(String testScriptDescription) {
		this.testScriptDescription = testScriptDescription;
	}

	public String getTestScriptExecutionInstruction() {
		return testScriptExecutionInstruction;
	}

	public void setTestScriptExecutionInstruction(String testScriptExecutionInstruction) {
		this.testScriptExecutionInstruction = testScriptExecutionInstruction;
	}

	public String getTestScriptDataset() {
		return testScriptDataset;
	}

	public void setTestScriptDataset(String testScriptDataset) {
		this.testScriptDataset = testScriptDataset;
	}

}
