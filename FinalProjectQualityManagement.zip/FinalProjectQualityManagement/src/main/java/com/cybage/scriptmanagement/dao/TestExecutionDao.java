package com.cybage.scriptmanagement.dao;

import java.util.List;

import com.cybage.scriptmanagement.model.TestExecutionModel;

public interface TestExecutionDao {

	// TestExecutionModel getTestExcution(int testExcutionId);

	TestExecutionModel InsertIntoDB(TestExecutionModel testExecutionModel);

	List<TestExecutionModel> showAllTestCase();

	TestExecutionModel deleteTestExecution(int testExcutionId, TestExecutionModel testExecutionModel);

	TestExecutionModel editTestExecution(int testExcutionId);

	TestExecutionModel updateIntoDB(TestExecutionModel testExecutionModel);

	TestExecutionModel getTestExecutiontById(int id);

}
