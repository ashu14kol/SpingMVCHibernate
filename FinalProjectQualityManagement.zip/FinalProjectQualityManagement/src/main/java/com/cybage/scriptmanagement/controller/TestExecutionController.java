package com.cybage.scriptmanagement.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.scriptmanagement.model.TestExecutionModel;
import com.cybage.scriptmanagement.service.TestExecutionService;

@Controller
public class TestExecutionController {
	@Autowired
	TestExecutionService testExecutionService;

	// To view add test execution form
	@RequestMapping("/addTestExecution")
	public ModelAndView showMessage1(@ModelAttribute("SpringWeb") TestExecutionModel testExecutionModel) {

		return new ModelAndView("addNewTestExecution", "command", testExecutionModel);
	}

	// insert new test execution into database
	@RequestMapping("/insertTestExecution")
	public ModelAndView addTestExecution(@RequestParam(value = "id", required = false, defaultValue = "1") int id,
			HttpServletRequest request, ModelMap model,
			@ModelAttribute("SpringWeb") TestExecutionModel testExecutionModel) {

		TestExecutionModel testExecutionModel1 = testExecutionService.insertIntoDb(testExecutionModel);

		ModelMapper modelMapper = new ModelMapper();

		List<TestExecutionModel> testExecutionList = testExecutionService.showAll();

		model.addAttribute("testExecutionList", testExecutionList);

		return new ModelAndView("allTestExecutions");
	}

	// To view list of all test execution(select query)
	@RequestMapping("/viewTestExecution")
	public ModelAndView showMessage2(@RequestParam(value = "id", required = false, defaultValue = "1") String id,
			HttpServletRequest request, ModelMap model) {

		List<TestExecutionModel> testExecutionList = testExecutionService.showAll();

		model.addAttribute("testExecutionList", testExecutionList);

		return new ModelAndView("allTestExecutions");

	}

	// delete test execution
	@RequestMapping("/deleteTestExecution/{id}")
	public ModelAndView deleteTestExecution(@PathVariable int id, HttpServletRequest request,
			@ModelAttribute("SpringWeb") TestExecutionModel testScriptModel) {

		TestExecutionModel testScriptModel1 = testExecutionService.deleteTestExecution(id, testScriptModel);

		return new ModelAndView("redirect:/viewTestExecution");
	}

	// fetch clicked test execution into view from database
	@RequestMapping("/editTestExecution/{id}")
	public ModelAndView editTestExecution(@PathVariable int id, HttpServletRequest request) {

		TestExecutionModel testExecutionModel = testExecutionService.editTestExecution(id);

		return new ModelAndView("editTestExecution", "command", testExecutionModel);
	}

	// update the particular record into database
	@RequestMapping(value = "/editTestExecution/updateTestExecution", method = RequestMethod.POST)
	public ModelAndView addStudent(@ModelAttribute("SpringWeb") TestExecutionModel testExecutionModel, ModelMap model) {

		TestExecutionModel tm1 = testExecutionService.updateIntoDB(testExecutionModel);

		List<TestExecutionModel> testExecutionList = testExecutionService.showAll();

		model.addAttribute("testExecutionList", testExecutionList);

		return new ModelAndView("redirect:/viewTestExecution");
	}

}
