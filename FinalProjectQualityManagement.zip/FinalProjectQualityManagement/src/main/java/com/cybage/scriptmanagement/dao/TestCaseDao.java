package com.cybage.scriptmanagement.dao;

import java.util.List;

import com.cybage.scriptmanagement.model.TestCaseModel;
import com.cybage.scriptmanagement.model.TestPlanModel;

public interface TestCaseDao {


	
	public TestCaseModel save(TestCaseModel t,TestPlanModel testPlanModel);
	public List<TestCaseModel> showAllTestCase();
	public void delete(int id);
	void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript, String data_set);
    public TestCaseModel geTestCaseById(int id);
    void update(TestCaseModel testCase);
}
