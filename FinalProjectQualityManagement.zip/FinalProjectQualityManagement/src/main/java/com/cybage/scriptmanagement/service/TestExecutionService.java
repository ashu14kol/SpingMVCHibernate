package com.cybage.scriptmanagement.service;

import java.util.List;

import com.cybage.scriptmanagement.model.TestExecutionModel;

public interface TestExecutionService {
	TestExecutionModel getTestExecution(int id);
	TestExecutionModel insertIntoDb(TestExecutionModel testExecutionModel);

	List<TestExecutionModel> showAll();

	TestExecutionModel deleteTestExecution(int id, TestExecutionModel tm);

	TestExecutionModel editTestExecution(int id);

	TestExecutionModel updateIntoDB(TestExecutionModel tm);
	TestExecutionModel findById(int testExcutionId);
    void updateUser(TestExecutionModel user);

}
