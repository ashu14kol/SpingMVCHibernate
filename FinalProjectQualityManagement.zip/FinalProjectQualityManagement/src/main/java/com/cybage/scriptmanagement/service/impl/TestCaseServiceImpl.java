package com.cybage.scriptmanagement.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.scriptmanagement.dao.TestCaseDao;
import com.cybage.scriptmanagement.dao.TestPlanDao;
import com.cybage.scriptmanagement.model.TestCaseModel;
import com.cybage.scriptmanagement.model.TestPlanModel;
import com.cybage.scriptmanagement.service.TestCaseService;

@Service
@Transactional
public class TestCaseServiceImpl implements TestCaseService {

	@Autowired
	TestCaseDao testCaseDao;
	@Autowired
	TestPlanDao testPlanDao;

	public TestCaseModel addData(TestCaseModel testCase,String testPlanTitle) {
		TestPlanModel testPlanModel=testPlanDao.getTestPlanByTitle(testPlanTitle);
		return testCaseDao.save(testCase,testPlanModel);
	}

	public void delete(int id) {

		testCaseDao.delete(id);

	}

	public List<TestCaseModel> showAll() {

		List<TestCaseModel> testcaselist = testCaseDao.showAllTestCase();
		return testcaselist;
	}

	public TestCaseModel getTestCaseById(int id) {
		TestCaseModel testcaseinfo = testCaseDao.geTestCaseById(id);
		return testcaseinfo;
	}

	public void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript,
			String data_set) {
		// TODO Auto-generated method stub
		
	}

	public void update(TestCaseModel testCase) {
		testCaseDao.update(testCase);
		
	}

	/*public void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript,
			String data_set) {
		
		testCaseDao.update(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);

	}*/

}
