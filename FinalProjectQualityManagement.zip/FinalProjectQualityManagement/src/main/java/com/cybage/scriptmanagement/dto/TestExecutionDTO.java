package com.cybage.scriptmanagement.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


public class TestExecutionDTO implements Serializable {

	private int testExcutionId;
	private String testExcutionTitle;
	private String testExcutionRunsOn;
	private String testExcutionRunsTestCase;
	private String testExcutionResult;
	private String testExcutionStatus;
	
	public int getTestExcutionId() {
		return testExcutionId;
	}
	public void setTestExcutionId(int testExcutionId) {
		this.testExcutionId = testExcutionId;
	}
	public String getTestExcutionTitle() {
		return testExcutionTitle;
	}
	public void setTestExcutionTitle(String testExcutionTitle) {
		this.testExcutionTitle = testExcutionTitle;
	}
	public String getTestExcutionRunsOn() {
		return testExcutionRunsOn;
	}
	public void setTestExcutionRunsOn(String testExcutionRunsOn) {
		this.testExcutionRunsOn = testExcutionRunsOn;
	}
	public String getTestExcutionRunsTestCase() {
		return testExcutionRunsTestCase;
	}
	public void setTestExcutionRunsTestCase(String testExcutionRunsTestCase) {
		this.testExcutionRunsTestCase = testExcutionRunsTestCase;
	}
	public String getTestExcutionResult() {
		return testExcutionResult;
	}
	public void setTestExcutionResult(String testExcutionResult) {
		this.testExcutionResult = testExcutionResult;
	}
	public String getTestExcutionStatus() {
		return testExcutionStatus;
	}
	public void setTestExcutionStatus(String testExcutionStatus) {
		this.testExcutionStatus = testExcutionStatus;
	}
	
	public TestExecutionDTO() {
		// TODO Auto-generated constructor stub
	}
	public TestExecutionDTO(int testExcutionId, String testExcutionTitle, String testExcutionRunsOn,
			String testExcutionRunsTestCase, String testExcutionResult, String testExcutionStatus) {
		super();
		this.testExcutionId = testExcutionId;
		this.testExcutionTitle = testExcutionTitle;
		this.testExcutionRunsOn = testExcutionRunsOn;
		this.testExcutionRunsTestCase = testExcutionRunsTestCase;
		this.testExcutionResult = testExcutionResult;
		this.testExcutionStatus = testExcutionStatus;
	}
	
	

	
}
