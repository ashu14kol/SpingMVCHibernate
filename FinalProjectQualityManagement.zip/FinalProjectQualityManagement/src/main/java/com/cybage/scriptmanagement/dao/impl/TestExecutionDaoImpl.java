package com.cybage.scriptmanagement.dao.impl;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cybage.scriptmanagement.dao.TestExecutionDao;
import com.cybage.scriptmanagement.model.TestExecutionModel;

@Repository
public class TestExecutionDaoImpl implements TestExecutionDao {
	@Autowired
	SessionFactory sf;

	public TestExecutionModel InsertIntoDB(TestExecutionModel testExecutionModel) {

		// Scanner sc = new Scanner(System.in);

		sf.getCurrentSession().save(testExecutionModel);

		return testExecutionModel;
	}

	public List<TestExecutionModel> showAllTestCase() {

		@SuppressWarnings("unchecked")
		List<TestExecutionModel> testExecutionList = sf.getCurrentSession().createQuery("from TestExecutionModel")
				.list();

		return testExecutionList;

	}

	public TestExecutionModel updateIntoDB(TestExecutionModel testScriptModel) {
		Scanner sc = new Scanner(System.in);

		sf.getCurrentSession().update(testScriptModel);

		return testScriptModel;
	}

	public TestExecutionModel deleteTestExecution(int testExcutionId, TestExecutionModel testExecutionModel) {
		Scanner sc = new Scanner(System.in);
		testExecutionModel = (TestExecutionModel) sf.getCurrentSession().load(TestExecutionModel.class,
				new Integer(testExcutionId));
		if (null != testExecutionModel) {
			sf.getCurrentSession().delete(testExecutionModel);
		}

		System.out.println("delete suceess..");

		return testExecutionModel;
	}

	public TestExecutionModel editTestExecution(int testExcutionId) {
		Criteria criteria = sf.getCurrentSession().createCriteria(TestExecutionModel.class);

		criteria.add(Restrictions.eq("id", testExcutionId));

		TestExecutionModel testExecutionModel = (TestExecutionModel) criteria.uniqueResult();

		return testExecutionModel;
	}

	public TestExecutionModel getTestExcution(int testExcutionId) {
		TestExecutionModel testModel = new TestExecutionModel();

		Query query = sf.getCurrentSession().createQuery("from TestExecutionModel");
		@SuppressWarnings("unchecked")
		List<TestExecutionModel> empList = query.list();

		return testModel;
	}
	/*
	 * public TestScriptModel getTestScriptById(int id) {
	 * 
	 * Object obj3 =
	 * sessionFactory.getCurrentSession().load(TestScriptModel.class, new
	 * Integer(id));
	 * sessionFactory.getCurrentSession().get(TestScriptModel.class, new
	 * Integer(id)); TestScriptModel s4 = (TestScriptModel) obj3;
	 * System.out.println(s4.toString()); return s4; }
	 */

	public TestExecutionModel getTestExecutiontById(int id) {
		Object obj3 = sf.getCurrentSession().load(TestExecutionModel.class, new Integer(id));
		sf.getCurrentSession().get(TestExecutionModel.class, new Integer(id));
		TestExecutionModel s4 = (TestExecutionModel) obj3;
		System.out.println(s4.toString());
		return s4;
	}
}
