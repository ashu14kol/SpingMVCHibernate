package com.cybage.scriptmanagement.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.scriptmanagement.dto.TestExecutionDTO;
import com.cybage.scriptmanagement.model.TestExecutionModel;
import com.cybage.scriptmanagement.service.TestExecutionService;

@RestController
@RequestMapping("/testExecution")
public class TestExecutionWebController {
	@Autowired
	TestExecutionService testExecutionService;

	// working add
	@RequestMapping(value = "/addTestExecution", method = RequestMethod.POST, headers = "Accept=application/json")
	public void getTestExecution(@RequestBody TestExecutionDTO testExecutiondto) {
		System.out.println("Test Execution Id" + testExecutiondto.getTestExcutionId());
		ModelMapper modelMapper = new ModelMapper();
		TestExecutionModel testExecutionModel = modelMapper.map(testExecutiondto, TestExecutionModel.class);
		testExecutionService.insertIntoDb(testExecutionModel);
	}

	// working delete
	@RequestMapping(value = "/deleteTestExecution/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public TestExecutionDTO getTestExecution(@PathVariable int id) {
		TestExecutionModel testExecutionModel = null;
		testExecutionModel = testExecutionService.deleteTestExecution(id, testExecutionModel);
		ModelMapper modelMapper = new ModelMapper();
		TestExecutionDTO testExecutionDTO = modelMapper.map(testExecutionModel, TestExecutionDTO.class);
		return testExecutionDTO;
	}

	// working allvalues
	@RequestMapping(value = "/allTestExecutions", method = RequestMethod.GET)
	public ResponseEntity<List<TestExecutionModel>> listAllExecutions() {
		List<TestExecutionModel> testExecutionModel = testExecutionService.showAll();
		if (testExecutionModel.isEmpty()) {
			return new ResponseEntity<List<TestExecutionModel>>(HttpStatus.NO_CONTENT);// You
																						// many
																						// decide
																						// to
																						// return
																						// HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<TestExecutionModel>>(testExecutionModel, HttpStatus.OK);
	}

	// to retrive single user
	@RequestMapping(value = "/getTestExecution/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public TestExecutionDTO getTestExecution1(@PathVariable int id) {
		TestExecutionModel testExecutionModel = testExecutionService.getTestExecution(id);
		ModelMapper modelMapper = new ModelMapper();
		TestExecutionDTO testExecutionDTO = modelMapper.map(testExecutionModel, TestExecutionDTO.class);
		return testExecutionDTO;
	}

	@RequestMapping(value = "/edit/updateTestExecution/{id}", method = RequestMethod.POST)
	public ResponseEntity<List<TestExecutionModel>> addStudent(@RequestBody TestExecutionModel testExecutionModel,
			@PathVariable int id) {

		TestExecutionModel tm1 = testExecutionService.updateIntoDB(testExecutionModel);

		List<TestExecutionModel> testExecutionModelList = testExecutionService.showAll();
		if (testExecutionModelList.isEmpty()) {
			return new ResponseEntity<List<TestExecutionModel>>(HttpStatus.NO_CONTENT);

		}
		return new ResponseEntity<List<TestExecutionModel>>(testExecutionModelList, HttpStatus.OK);
	}
}