package com.cybage.scriptmanagement.dto;

import java.io.Serializable;
import java.util.Set;

import com.cybage.scriptmanagement.model.TestCaseModel;

public class TestPlanDto implements Serializable {

	private static final long serialVersionUID = 1L;
	Integer testPlanId;
	String testPlanTitle;
	String testPlanDescription;
	String testPlanStatus;
	String testPlanType;
	//Set<TestCaseModel> testCases;

public TestPlanDto() {
	// TODO Auto-generated constructor stub
}

	public TestPlanDto(Integer testPlanId, String testPlanTitle, String testPlanDescription, String testPlanStatus,
			String testPlanType) {
		super();
		this.testPlanId = testPlanId;
		this.testPlanTitle = testPlanTitle;
		this.testPlanDescription = testPlanDescription;
		this.testPlanStatus = testPlanStatus;
		this.testPlanType = testPlanType;
	}
	public Integer getTestPlanId() {
		return testPlanId;
	}


	public void setTestPlanId(Integer testPlanId) {
		this.testPlanId = testPlanId;
	}


	public String getTestPlanTitle() {
		return testPlanTitle;
	}


	public void setTestPlanTitle(String testPlanTitle) {
		this.testPlanTitle = testPlanTitle;
	}


	public String getTestPlanDescription() {
		return testPlanDescription;
	}


	public void setTestPlanDescription(String testPlanDescription) {
		this.testPlanDescription = testPlanDescription;
	}


	public String getTestPlanStatus() {
		return testPlanStatus;
	}


	public void setTestPlanStatus(String testPlanStatus) {
		this.testPlanStatus = testPlanStatus;
	}


	public String getTestPlanType() {
		return testPlanType;
	}

	public void setTestPlanType(String testPlanType) {
		this.testPlanType = testPlanType;
	}

/*	public Set<TestCaseModel> getTestCases() {
		return testCases;
	}


	public void setTestCases(Set<TestCaseModel> testCases) {
		this.testCases = testCases;
	}*/


	@Override
	public String toString() {
		/*StringBuilder sb = new StringBuilder(" \n TestCase's title ");
		for (TestCaseModel testcaseModel : testCases)
			sb.append(testcaseModel.getTitle() + " ");*/
		return "TestPlan Id=" + testPlanId 
				+ ", TestPlan Title=" + testPlanTitle 
				+ ", TestPlan Description="+ testPlanDescription 
				+ ", TestPlan Status=" + testPlanStatus 
				+ ", TestPlan Type=" + testPlanType
				/*+ sb.toString()*/ ;
	}

}
