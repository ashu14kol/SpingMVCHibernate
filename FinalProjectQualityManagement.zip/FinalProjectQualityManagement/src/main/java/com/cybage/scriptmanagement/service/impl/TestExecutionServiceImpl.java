package com.cybage.scriptmanagement.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.scriptmanagement.dao.TestExecutionDao;
import com.cybage.scriptmanagement.model.TestExecutionModel;
import com.cybage.scriptmanagement.service.TestExecutionService;

@Service
@Transactional
public class TestExecutionServiceImpl implements TestExecutionService {

	@Autowired
	TestExecutionDao testExecutionDao;
	private static List<TestExecutionModel> testExecutionModels;

	public TestExecutionModel insertIntoDb(TestExecutionModel testExecutionModel) {
		// TODO Auto-generated method stub
		return testExecutionDao.InsertIntoDB(testExecutionModel);
	}

	public List<TestExecutionModel> showAll() {
		// TODO Auto-generated method stub
		List<TestExecutionModel> testExecutionList = testExecutionDao.showAllTestCase();
		return testExecutionList;
	}

	public TestExecutionModel deleteTestExecution(int id, TestExecutionModel tm) {
		// TODO Auto-generated method stub
		return testExecutionDao.deleteTestExecution(id, tm);
	}

	public TestExecutionModel editTestExecution(int id) {
		// TODO Auto-generated method stub
		return testExecutionDao.editTestExecution(id);
	}

	public TestExecutionModel updateIntoDB(TestExecutionModel tm) {
		// TODO Auto-generated method stub
		return testExecutionDao.updateIntoDB(tm);
	}

	/*
	 * public TestExecutionModel getTestExecution(str testExcutionId) { // TODO
	 * Auto-generated method stub return
	 * testExecutionDao.getTestExcution(testExcutionId); }
	 */
	// getTestExcution(testExcutionId);
	public TestExecutionModel findById(int testExcutionId) {
		// TODO Auto-generated method stub
		for (TestExecutionModel testExecutionModel : testExecutionModels) {
			if (testExecutionModel.getTestExcutionId() == testExcutionId) {
				return testExecutionModel;
			}
		}
		return null;
	}

	public void updateUser(TestExecutionModel user) {
		int index = testExecutionModels.indexOf(user);
		testExecutionModels.set(index, user);
	}

	@Transactional
	public TestExecutionModel getTestExecution(int id) {
		// TODO Auto-generated method stub
		TestExecutionModel testexecutioninfo = testExecutionDao.getTestExecutiontById(id);
		return testexecutioninfo;
	}

}
