package com.cybage.scriptmanagement.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.scriptmanagement.model.TestCaseModel;
import com.cybage.scriptmanagement.model.TestPlanModel;
import com.cybage.scriptmanagement.model.TestScriptModel;
import com.cybage.scriptmanagement.service.TestCaseService;
import com.cybage.scriptmanagement.service.TestPlanService;
import com.cybage.scriptmanagement.service.TestScriptService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@Controller
public class TestScriptController {
	@Autowired
	TestScriptService testScriptService;

	// To view add test script form
	@RequestMapping("/add")
	public ModelAndView showMessage1(@ModelAttribute("SpringWeb") TestScriptModel testScriptModel) {

		return new ModelAndView("addNewTestScript", "command", testScriptModel);
	}

	// insert new test script into database
	@RequestMapping("/insert")
	public ModelAndView addTestScript(@RequestParam(value = "id", required = false, defaultValue = "1") int id,
			HttpServletRequest request, ModelMap model, @ModelAttribute("SpringWeb") TestScriptModel testScriptModel) {

		TestScriptModel testScriptModel1 = testScriptService.insertIntoDb(testScriptModel);

		ModelMapper modelMapper = new ModelMapper();

		List<TestScriptModel> testScriptList = testScriptService.showAll();

		model.addAttribute("testScriptList", testScriptList);

		return new ModelAndView("allTestScripts");
	}

	// To view list of all test scripts(select query)
	@RequestMapping("/view")
	public ModelAndView showMessage2(@RequestParam(value = "id", required = false, defaultValue = "1") String id,
			HttpServletRequest request, ModelMap model) {

		List<TestScriptModel> testScriptList = testScriptService.showAll();

		model.addAttribute("testScriptList", testScriptList);

		return new ModelAndView("allTestScripts");

	}

	// delete test script
	@RequestMapping("/delete/{id}")
	public ModelAndView deleteTestScript(@PathVariable int id, HttpServletRequest request,
			@ModelAttribute("SpringWeb") TestScriptModel testScriptModel) {

		TestScriptModel testScriptModel1 = testScriptService.deleteTestScript(id, testScriptModel);

		return new ModelAndView("redirect:/view");
	}

	// fetch clicked test script into view from database
	@RequestMapping("/edit/{id}")
	public ModelAndView editTestScript(@PathVariable int id, HttpServletRequest request) {

		TestScriptModel testScriptModel = testScriptService.editTestScript(id);

		return new ModelAndView("editTestScript", "command", testScriptModel);
	}

	// update the particular record into database
	@RequestMapping(value = "/edit/updateTestScript", method = RequestMethod.POST)
	public ModelAndView addStudent(@ModelAttribute("SpringWeb") TestScriptModel testScriptModel, ModelMap model) {

		TestScriptModel tm1 = testScriptService.updateIntoDB(testScriptModel);

		List<TestScriptModel> testScriptList = testScriptService.showAll();

		model.addAttribute("testScriptList", testScriptList);

		return new ModelAndView("redirect:/view");
	}
	// ****************************

	@RequestMapping(value = "/testcase")
	public ModelAndView test(HttpServletResponse response) throws IOException {
		return new ModelAndView("home");
	}

	@Autowired
	TestCaseService testCaseService;
	@Autowired
	TestPlanService testPlanService;

	@RequestMapping(value = "/createtestcase")
	public ModelAndView test2(HttpServletResponse response, ModelMap model) throws IOException {

		List<TestCaseModel> testcaselist = testCaseService.showAll();
		List<TestPlanModel> testPlanList = testPlanService.getAllTestPlans();

		model.addAttribute("testcaselist", testcaselist);
		model.addAttribute("testPlanList", testPlanList);

		// ===============

		List<TestScriptModel> testScriptList = testScriptService.showAll();

		model.addAttribute("testScriptList", testScriptList);

		return new ModelAndView("createtestcase").addObject(new TestCaseModel());
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView test3(ModelMap model, @ModelAttribute("testCaseModel") TestCaseModel testCase)
			throws IOException {
		String testPlanTitle = testCase.getTestPlanModel().getTestPlanTitle();
		TestCaseModel m = testCaseService.addData(testCase, testPlanTitle);
		// testCaseService.addData(testCase);

		List<TestCaseModel> testcaselist = testCaseService.showAll();

		model.addAttribute("testcaselist", testcaselist);
		System.out.println(testcaselist.toString());
		return new ModelAndView("redirect:/createtestcase");
	}

	@RequestMapping(value = "/showalltestcase")
	public ModelAndView test3(HttpServletResponse response, ModelMap model) throws IOException {

		List<TestCaseModel> testcaselist = testCaseService.showAll();
		model.addAttribute("testcaselist", testcaselist);
		return new ModelAndView("alltestcases");
	}

	@RequestMapping(value = "/deleteTestCase/{id}")
	public ModelAndView removeTestCase(@PathVariable("id") int id) {
		System.out.println("delete");
		testCaseService.delete(id);
		return new ModelAndView("redirect:/createtestcase");
	}

	@RequestMapping(value = "/editTestCase/{id}")
	public ModelAndView editTestCase(@PathVariable("id") int id, ModelMap model) {
		List<TestCaseModel> testcaselist = testCaseService.showAll();
		TestCaseModel testcaseinfo = testCaseService.getTestCaseById(id);
		model.addAttribute("testcaselist", testcaselist);
		model.addAttribute("testcaseinfo", testcaseinfo);
		
		
		
		List<TestPlanModel> testPlanList = testPlanService.getAllTestPlans();
		model.addAttribute("testPlanList", testPlanList);
		
		
		
		return new ModelAndView("edittestcaselist");
	}

	@RequestMapping(value = "editTestCase/updateTestCase")
	public /* String */ ModelAndView test4(HttpServletResponse response,
			HttpServletRequest request,@ModelAttribute("testCaseModel") TestCaseModel testCase) throws IOException {
		//int testCase_id = Integer.parseInt(request.getParameter("id"));
		//String testCase_title = request.getParameter("title");
		//String testCase_desc = request.getParameter("desc");
		//String used_TsetScript = request.getParameter("test_script");
		//System.out.println(used_TsetScript);
		//String data_set = request.getParameter("data_set");

		//testCaseService.update(testCase_id, testCase_title, testCase_desc, used_TsetScript, data_set);
		testCaseService.update(testCase);
		List<TestCaseModel> testcaselist = testCaseService.showAll();

		/* model.addAttribute("testcaselist", testcaselist); */
		System.out.println("helooo");
		return new ModelAndView("redirect:/createtestcase").addObject("testcaselist", testcaselist);
	}

	@RequestMapping(value = "rest/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestCaseModel> getUser(@PathVariable("id") int id) {
		System.out.println("Fetching User with id " + id);
		TestCaseModel testCase = testCaseService.getTestCaseById(id);
		ObjectMapper objectmapper = new ObjectMapper();

		if (testCase == null) {
			System.out.println("User with id " + id + " not found");
			return new ResponseEntity<TestCaseModel>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<TestCaseModel>(testCase, HttpStatus.OK);
	}
}