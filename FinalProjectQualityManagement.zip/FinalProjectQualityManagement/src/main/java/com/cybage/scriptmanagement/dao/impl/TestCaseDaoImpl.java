package com.cybage.scriptmanagement.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cybage.scriptmanagement.dao.TestCaseDao;
import com.cybage.scriptmanagement.model.TestCaseModel;
import com.cybage.scriptmanagement.model.TestPlanModel;

@Repository
public class TestCaseDaoImpl implements TestCaseDao {

	@Autowired
	SessionFactory sessionFactory;

	public TestCaseModel save(TestCaseModel testCaseModel,TestPlanModel testPlanModel) {
		if (testPlanModel != null && testPlanModel.addTestcaseModel(testCaseModel)) {
			System.out.println(testCaseModel);
			return testCaseModel;
		}

		return null;

	}

	public List<TestCaseModel> showAllTestCase() {

		List<TestCaseModel> testcaselist = sessionFactory.getCurrentSession().createCriteria(TestCaseModel.class)
				.list();

		return testcaselist;
	}

	public void delete(int id) {

		Object obj3 = sessionFactory.getCurrentSession().load(TestCaseModel.class, new Integer(id));
		TestCaseModel s4 = (TestCaseModel) obj3;
	     sessionFactory.getCurrentSession().delete(s4);

	}

	public void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript,
			String data_set) {

		Object obj3 = sessionFactory.getCurrentSession().load(TestCaseModel.class, new Integer(testCase_id));
		TestCaseModel s4 = (TestCaseModel) obj3;
		s4.setTestCase_id(testCase_id);
		s4.setTestCase_title(testCase_title);
		s4.setTestCase_desc(testCase_desc);
		s4.setUsed_TsetScript(used_TsetScript);
		s4.setData_Set(data_set);
	}

	public TestCaseModel geTestCaseById(int id) {

		Object obj3 = sessionFactory.getCurrentSession().load(TestCaseModel.class, new Integer(id));
		TestCaseModel s4 = (TestCaseModel) obj3;
		System.out.println(s4);

		return s4;
	}
	public void update(TestCaseModel testCase){
		
		sessionFactory.getCurrentSession().update(testCase);
	}

}
