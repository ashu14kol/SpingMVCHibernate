package com.cybage.scriptmanagement.service;

import java.util.List;

import com.cybage.scriptmanagement.model.TestPlanModel;

public interface TestPlanService {

	TestPlanModel addTestPlan(TestPlanModel testPlan);
	
	TestPlanModel getTestPlan();
	
	TestPlanModel getTestPlanByTitle(String planTitle);
	
	List<TestPlanModel> getAllTestPlans();
	
	TestPlanModel deleteTestPlan(int id);
	
	TestPlanModel editTestPlan(int id);
	
	TestPlanModel updateTestPlan(TestPlanModel testPlanModel);
	
	TestPlanModel getTestPlan(int id);

}
