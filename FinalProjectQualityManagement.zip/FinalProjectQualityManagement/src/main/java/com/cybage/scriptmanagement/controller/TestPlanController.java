package com.cybage.scriptmanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.scriptmanagement.model.TestCaseModel;
import com.cybage.scriptmanagement.model.TestPlanModel;
import com.cybage.scriptmanagement.service.TestCaseService;
import com.cybage.scriptmanagement.service.TestPlanService;

@Controller
public class TestPlanController {
	
	@Autowired
	TestPlanService testPlanService;
	@Autowired
	TestCaseService testCaseService;

	@RequestMapping(value = "/addTestPlan",method = RequestMethod.GET)
	public ModelAndView showTestPlanForm(TestPlanModel testPlanModel) {
		System.out.println("hiiiiiiiiiiiiiii");
		ModelAndView modelAndView=new ModelAndView("addTestPlan");
		modelAndView.addObject(testPlanModel);
		return modelAndView;
	}

	@RequestMapping(value = "/addTestPlan", method = RequestMethod.POST)
	public ModelAndView processForm(TestPlanModel testPlanModel, Model map, HttpSession hs) {
		System.out.println(testPlanModel);
		TestPlanModel validTestPlanModel = testPlanService.addTestPlan(testPlanModel);
		List<TestPlanModel> testPlanList= testPlanService.getAllTestPlans();
		ModelAndView mv = new ModelAndView("viewAllTestPlan");
		mv.addObject("testPlanList",testPlanList);
		return mv;
	}
	
	
	@RequestMapping("/viewTestPlan")
	public ModelAndView showMessage12(@RequestParam(value = "id", required = false) String id,
			HttpServletRequest request) {

		List<TestPlanModel> testPlanList= testPlanService.getAllTestPlans();
		ModelAndView mv = new ModelAndView("viewAllTestPlan");
		mv.addObject("testPlanList",testPlanList);
		return mv;
		}
	
	@RequestMapping("/deleteTestPlan/{id}")
	public ModelAndView deleteTestScript11(@PathVariable int id, HttpServletRequest request
			 ) {

		TestPlanModel testPlanModel = testPlanService.deleteTestPlan(id);
		return new ModelAndView("redirect:/viewTestPlan");
	}

	@RequestMapping("/editTestPlan/{id}")
	public ModelAndView editTestPlan(@PathVariable int id, HttpServletRequest request) {

		TestPlanModel testPlanModel = testPlanService.editTestPlan(id);

		return new ModelAndView("editTestPlan", "testPlanModel", testPlanModel);
	}

	
	
	
	@RequestMapping(value = "/editTestPlan/updateTestPlan", method = RequestMethod.POST)
	public ModelAndView addStudent12(TestPlanModel testPlanModel) {

		TestPlanModel testPlanModel1 = testPlanService.updateTestPlan(testPlanModel);

		List<TestPlanModel> testPlanList = testPlanService.getAllTestPlans();

		return new ModelAndView("redirect:/viewTestPlan").addObject("testPlanList", testPlanList);
	}
	
	
	
/*	
	@RequestMapping(value = "/addTestCase")
	public ModelAndView showTestCase() {
		System.out.println("helooooo");
		ArrayList<String> planTitles=testCaseService.getTestPlanTitles();
		ModelAndView model=new ModelAndView("addTestCase");
		model.addObject(new TestCaseModel());
		model.addObject("planTitles",planTitles);
		return model;
	}
	
	
	
	@RequestMapping(value = "/addTestCase",method = RequestMethod.POST)
	public ModelAndView processTestCase(TestCaseModel testCaseModel) {
		System.out.println("in post of add test case"+testCaseModel);
		String testPlanTitle= testCaseModel.getTestPlanModel().getTestPlanTitle();
		TestCaseModel m=testCaseService.addTestCase(testCaseModel,testPlanTitle);
		System.out.println(m);
		ModelAndView modelAndView=new ModelAndView("valid");
		modelAndView.addObject("Object12",m);
		return modelAndView;
		
				
	}*/
	
	
	
	
	
	
	
	
	
/*	@RequestMapping(value="/JsonTest",produces="application/json",method = RequestMethod.GET)
	public  TestPlanModel showTestPlan() {
		//List<TestPlan> testPlans = Arrays.asList(new TestPlan("a","xyz","executing"), new TestPlan("b","def","running"),
			//	new TestPlan("c", "abc","ready"));
		TestPlanModel testObject=new TestPlanModel("a","xyz","executing");
		System.out.println("in show testPlans JSON");
		return testObject;
		
	}*/
}
