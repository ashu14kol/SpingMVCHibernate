package com.cybage.scriptmanagement.service;

import java.util.List;

import com.cybage.scriptmanagement.model.TestCaseModel;



public interface TestCaseService {
	
	
	
	public TestCaseModel addData(TestCaseModel testCase,String s);
	public void delete(int id);
	public List<TestCaseModel> showAll();
	public TestCaseModel getTestCaseById(int id);
	public void update(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript, String data_set);
	public void update(TestCaseModel testCase);

}
