package com.cybage.scriptmanagement.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.scriptmanagement.dto.TestScriptDTO;
import com.cybage.scriptmanagement.model.TestScriptModel;
import com.cybage.scriptmanagement.service.TestScriptService;

@RestController
@RequestMapping("/testScript")
public class TestScriptRestController {
	@Autowired
	TestScriptService testScriptService;

	// fetch single record on id
	@RequestMapping(value = "/getTestScript/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public TestScriptDTO getTestScriptById(@PathVariable int id) {

		TestScriptModel testScriptModel = testScriptService.getTestScripts(id);
		ModelMapper modelMapper = new ModelMapper();
		TestScriptDTO testScriptDTO = modelMapper.map(testScriptModel, TestScriptDTO.class);
		return testScriptDTO;
	}

	// add to db json input from body
	@RequestMapping(value = "/addTestScript", method = RequestMethod.POST, headers = "Accept=application/json")
	public void addTestScript(@RequestBody TestScriptDTO testCaseDto) {
		System.out.println("Test Case Id" + testCaseDto.getTestScriptId());
		ModelMapper modelMapper = new ModelMapper();
		TestScriptModel testScriptModel = modelMapper.map(testCaseDto, TestScriptModel.class);
		testScriptService.insertIntoDb(testScriptModel);
	}

	// delete on id
	@RequestMapping(value = "/deleteTestScript/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public TestScriptDTO deleteTestScript(@PathVariable int id) {
		TestScriptModel testScriptModel = testScriptService.deleteTestScript(id, new TestScriptModel());
		ModelMapper modelMapper = new ModelMapper();
		TestScriptDTO testScriptDTO = modelMapper.map(testScriptModel, TestScriptDTO.class);
		return testScriptDTO;
	}

	// to view all testScripts in database
	@RequestMapping(value = "/viewAllTestScripts", method = RequestMethod.GET)
	public ResponseEntity<List<TestScriptModel>> viewAllTestScripts() {
		List<TestScriptModel> testScriptModelList = testScriptService.showAll();
		if (testScriptModelList.isEmpty()) {
			return new ResponseEntity<List<TestScriptModel>>(HttpStatus.NO_CONTENT);

		}
		return new ResponseEntity<List<TestScriptModel>>(testScriptModelList, HttpStatus.OK);
	}

	// update test script by accepting id from user
	@RequestMapping(value = "/edit/updateTestScript/{id}", method = RequestMethod.PUT)
	public ResponseEntity<List<TestScriptModel>> updateTestScript(@RequestBody TestScriptModel testScriptModel,
			@PathVariable int id) {

		TestScriptModel tm1 = testScriptService.updateIntoDB(testScriptModel);

		List<TestScriptModel> testScriptModelList = testScriptService.showAll();
		if (testScriptModelList.isEmpty()) {
			return new ResponseEntity<List<TestScriptModel>>(HttpStatus.NO_CONTENT);

		}
		return new ResponseEntity<List<TestScriptModel>>(testScriptModelList, HttpStatus.OK);
	}

}
