package com.cybage.scriptmanagement.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cybage.scriptmanagement.dao.TestScriptDao;
import com.cybage.scriptmanagement.model.TestScriptModel;

@Repository
public class TestScriptDaoImpl implements TestScriptDao {

	@Autowired
	SessionFactory sessionFactory;

	// Add test script into database
	public TestScriptModel InsertIntoDB(TestScriptModel testScriptModel) {

		sessionFactory.getCurrentSession().save(testScriptModel);

		return testScriptModel;
	}

	// view all available test scripts
	public List<TestScriptModel> showAllTestCase() {

		@SuppressWarnings("unchecked")
		List<TestScriptModel> testScriptList = sessionFactory.getCurrentSession().createQuery("from TestScriptModel")
				.list();

		return testScriptList;

	}

	// delete test script from existing table
	public TestScriptModel deleteTestScript(int testScriptId, TestScriptModel testScriptModel) {

		testScriptModel = (TestScriptModel) sessionFactory.getCurrentSession().load(TestScriptModel.class,
				new Integer(testScriptId));
		if (null != testScriptModel) {
			sessionFactory.getCurrentSession().delete(testScriptModel);
		}

		return testScriptModel;
	}

	// get selected test script data into form for editing
	public TestScriptModel editTestScript(int testScriptId) {

		Criteria criteria = sessionFactory.getCurrentSession().createCriteria(TestScriptModel.class);

		criteria.add(Restrictions.eq("id", testScriptId));

		TestScriptModel testScriptModel = (TestScriptModel) criteria.uniqueResult();

		return testScriptModel;
	}

	// edit test script and put it into database
	public TestScriptModel updateIntoDB(TestScriptModel testScriptModel) {

		sessionFactory.getCurrentSession().update(testScriptModel);

		return testScriptModel;
	}
	
	public TestScriptModel getTestScriptById(int id) {

		Object obj3 = sessionFactory.getCurrentSession().load(TestScriptModel.class, new Integer(id));
		sessionFactory.getCurrentSession().get(TestScriptModel.class, new Integer(id));
		TestScriptModel s4 = (TestScriptModel) obj3;
		System.out.println(s4.toString());
		return s4;
	}

}
