package com.cybage.scriptmanagement.service;

import java.util.List;

import com.cybage.scriptmanagement.model.TestScriptModel;

public interface TestScriptService {

	TestScriptModel getTestScripts(int id);

	TestScriptModel insertIntoDb(TestScriptModel testScriptModel);

	List<TestScriptModel> showAll();

	TestScriptModel deleteTestScript(int id, TestScriptModel tm);

	TestScriptModel editTestScript(int id);
	

	TestScriptModel updateIntoDB(TestScriptModel tm);

}
