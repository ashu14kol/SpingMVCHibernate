package com.cybage.scriptmanagement.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.cybage.scriptmanagement.model.TestPlanModel;


//@Lazy(value = false)

public class TestCaseDTO {


	private int testCase_id;


	private String testCase_title;


	private String testCase_desc;


	private String used_TsetScript;

	
	private String data_Set;
	
	TestPlanModel testPlanModel; 

	
	
	
	
	
	
	public TestCaseDTO(int testCase_id, String testCase_title, String testCase_desc, String used_TsetScript,
			String data_Set, TestPlanModel testPlanModel) {
		super();
		this.testCase_id = testCase_id;
		this.testCase_title = testCase_title;
		this.testCase_desc = testCase_desc;
		this.used_TsetScript = used_TsetScript;
		this.data_Set = data_Set;
		this.testPlanModel = testPlanModel;
	}

	public int getTestCase_id() {
		return testCase_id;
	}

	public void setTestCase_id(int testCase_id) {
		this.testCase_id = testCase_id;
	}
	
	
	

	public String getTestCase_title() {
		return testCase_title;
	}

	public void setTestCase_title(String testCase_title) {
		this.testCase_title = testCase_title;
	}

	
	
	public String getTestCase_desc() {
		return testCase_desc;
	}

	public void setTestCase_desc(String testCase_desc) {
		this.testCase_desc = testCase_desc;
	}

	
	
	public String getUsed_TsetScript() {
		return used_TsetScript;
	}

	public void setUsed_TsetScript(String used_TsetScript) {
		this.used_TsetScript = used_TsetScript;
	}

	
	
	public String getData_Set() {
		return data_Set;
	}

	public void setData_Set(String data_Set) {
		this.data_Set = data_Set;
	}

	
	

	public TestPlanModel getTestPlanModel() {
		return testPlanModel;
	}

	public void setTestPlanModel(TestPlanModel testPlanModel) {
		this.testPlanModel = testPlanModel;
	}
	
	
	
	
	


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((testCase_title == null) ? 0 : testCase_title.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TestCaseDTO other = (TestCaseDTO) obj;
		if (testCase_title == null) {
			if (other.testCase_title != null)
				return false;
		} else if (!testCase_title.equals(other.testCase_title))
			return false;
		return true;
	}
	
	
	

	@Override
	public String toString() {
		return "TestCaseModel [testCase_id=" + testCase_id + ", testCase_title=" + testCase_title + ", testCase_desc="
				+ testCase_desc + ", used_TsetScript=" + used_TsetScript + ", data_Set=" + data_Set + ",included in testPlan=" + testPlanModel.getTestPlanTitle() + "]";
	}

}
